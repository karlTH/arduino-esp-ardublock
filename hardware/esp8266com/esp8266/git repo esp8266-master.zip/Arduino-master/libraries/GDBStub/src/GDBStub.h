#ifndef GDBSTUB_H
#define GDBSTUB_H

// this header is intentionally left blank

bool crash_for_gdb = 1;

#endif //GDBSTUB_H
